using UnityEngine;
using UnityEngine.UI;


public class FBS_Script : MonoBehaviour
{
    public Text rannumtxt, gamepoints, infotext;
    public Button fizzbtn, buzzbtn, fizzbuzzbtn, normnumbtn, newnumbtn, resetButton;
    public Image backround;
    public AudioSource correct, incorrect;
    private Color red = Color.red, green = Color.green, white = Color.white;
    private int randnum, points, fizz = 3, buzz = 5;
    private string[] antworten;
   

    private void Start()
    {
        backround.color = Color.white;
        points = 0;
        antworten = new string[7];
        antworten[0] = "Danger! Your number is only divisible by 3 and 5 if its sum is divisible by 3 and if the last number is a 5 or 0.";
        antworten[1] = "Danger! Their number is only divisible by 3 if their sum is divisible by 3.";
        antworten[2] = "Danger! Your number is only divisible by 5 if your last number is a 5 or a 0.";
        antworten[3] = "Danger! Your number is divisible by 3 and 5";
        antworten[4] = "Danger! Your number is divisible by 3";
        antworten[5] = "Danger! Your number is only divisible by 5";
        antworten[6] = "";
    }

    private void Update()
    {
        gamepoints.text = "Points: " + points.ToString();

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            CheckFizzBuzz();
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            CheckNormalNumber();
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            CheckFizz();
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            CheckBuzz();
        }
        else if (Input.GetKeyDown(KeyCode.Space))
        {
            RandomNumber();
        }
    }

    public void IncorrectAnswer()
    {
        backround.color = red;
        incorrect.Play();
    }

    public void CorrectAnswer()
    {
        backround.color = green;
        points += 20;
        correct.Play();
    }

    public void ResetPoints()
    {
        points = 0;
    }

    public void RandomNumber()
    {
        randnum = Random.Range(0, 1001);
        rannumtxt.text = randnum.ToString();
        backround.color = white;
        infotext.text = antworten[6];
    }

    public void CheckFizzBuzz()
    {
        if (randnum % fizz == 0 && randnum % buzz == 0)
        {
            CorrectAnswer();
        }
        else
        {
            infotext.text = antworten[0];
            IncorrectAnswer();
        }
    }

    public void CheckFizz()
    {
        if (randnum % fizz == 0 && randnum % buzz != 0)
        {
            CorrectAnswer();
        }
        else
        {
            IncorrectAnswer();
            infotext.text = antworten[1];
        }
    }

    public void CheckBuzz()
    {
        if (randnum % buzz == 0 && randnum % fizz != 0)
        {
            CorrectAnswer();
        }
        else
        {
            IncorrectAnswer();
            infotext.text = antworten[2];
        }
    }

    public void CheckNormalNumber()
    {
        if (randnum % fizz != 0 && randnum % buzz != 0)
        {
            CorrectAnswer();
        }
        else
        {
            IncorrectAnswer();

            if (randnum % fizz == 0 && randnum % buzz == 0)
            {
                infotext.text = antworten[3];
            }

            else if (randnum % fizz == 0 && randnum % buzz != 0)
            {
                infotext.text = antworten[4];
            }
            else if (randnum % buzz == 0 && randnum % fizz != 0)
            {
                infotext.text = antworten[5];
            }
        }
    }
}
